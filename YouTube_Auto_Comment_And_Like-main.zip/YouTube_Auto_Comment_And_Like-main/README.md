# YouTube Auto Comment And Like (YACAL)
* Programatically Comment and Like Videos on YouTube without needing a Google oauth key.
* Ready to go for modern updated (November 2020) x64 linux. Originally build on kali.

## How to Build
* cd YouTube_Auto_Comment_And_Like
* chmod +x You*
* (as root) ./YouTube_Auto_Comment_And_Like_Config.py

* The chromedriver version you download needs to match your version of chrome.
* Check Chrome version in browser with chrome://version/. 
* If your version is not 86, manually download from https://chromedriver.storage.googleapis.com

* Authentication to YouTube is done with a traditional username and password for a google account held in the persistant cookie.
* The authentication will occur during the running of ./YouTube_Auto_Comment_And_Like_Config.py. 

## Useage
* Change the channel_url, video_name, my_comment, and like variables in YouTube_Auto_Comment_And_like.py
* ./YouTube_Auto_Comment_And_like.py (as root)

## Inspiration
* NPR Up First needed to be notified early and often of how terrible they are at doing news.
## Contact
Please contact me at CoolHandSquid32@gmail.com for suggestions and ideas!
